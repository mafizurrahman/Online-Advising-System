-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2019 at 07:09 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Dept` varchar(20) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `phoneCode` int(20) NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `Type`, `Dept`, `Course`, `phoneCode`, `phone`) VALUES
(28, 'shafiq', 'amahfuzmarjan777@gmail.com', 'f4f5ba4dc219c8d30ed7c09c4583022d', 'student', 'CSE', '', 0, 0),
(32, 'rakib', 'rakib@gmail.com', 'a36949228c1d9146cace6359d88968e8', 'student', 'CSE', '', 0, 0),
(35, 'he', 'aeaaaaa@gmail.com', '6f96cfdfe5ccc627cadf24b41725caa4', 'student', 'cse', '', 0, 0),
(36, 'k', 'aaaaaalawaaa@gmail.com', '8ce4b16b22b58894aa86c421e8759df3', 'student', 'cse', '', 0, 0),
(39, 'shanto', 'mahfuzzmarjan777@gmail.com', '0cc175b9c0f1b6a831c399e269772661', 'teacher', 'CSE', '', 0, 0),
(40, 'aaaaaaaam', 'aaaa3aa@gmail.com', '0cc175b9c0f1b6a831c399e269772661', 'teacher', 'cse', '', 0, 0),
(41, 'ramim', 'ramim@gmail.om', '515c1c7d49f233f8bb0557fa556cb728', 'student', 'CSE', '', 0, 0),
(42, 'robin', 'robin@gmail.com', '8ee60a2e00c90d7e00d5069188dc115b', 'student', 'CSE', '', 0, 0),
(44, 'mkn', 'an@gmail.com', '8ce4b16b22b58894aa86c421e8759df3', 'teacher', 'CSE', '', 0, 0),
(45, 'msrn', 'msrn@gmail.com', '770b1729da61981979a32a95959ccc63', 'teacher', 'ece', '', 0, 0),
(47, 'marjan', 'marjan@gmail.com', '122f961db675f6a45b998594471a990b', 'student', 'CSE', '', 0, 0),
(48, 'noyon', 'noyon@gmail.com', 'c74ca17aca5cb1bb935d10aae5186d8d', 'student', 'cse', '', 0, 0),
(49, 'ali', 'ali@gmail.com', 'df5990d13480fba4d93fb9b369d90bc5', 'teacher', 'CSE', '', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
