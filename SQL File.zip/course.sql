-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2019 at 02:32 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `courseid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `username`, `email`, `password`, `courseid`) VALUES
(6, 'pikachu', 'pikachu@gmail.com', '9ce44f88a25272b6d9cbb430ebbcfcf1', 'gen201'),
(7, 'abul', 'a1@gmail.com', '1c3368c0c9381843c2a29f42420eb63e', 'gen201'),
(8, 'pranto', 'a21@gmail.com', '23d01cf2b684e1bff721d569027edd68', 'cse205'),
(14, 'atikur', 'rmafizur10@gmail.com', '099b3b060154898840f0ebdfb46ec78f', 'gen201'),
(15, 'don', 'mahfuzmarjan777@gmail.com', '6a01bfa30172639e770a6aacb78a3ed4', 'cse102'),
(16, 'nice', 'nie@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'cse105'),
(17, 'shafiq', 'rmafizur10@gmail.com', 'f4f5ba4dc219c8d30ed7c09c4583022d', 'phy103'),
(18, 'ko', 'koa@gmail.com', 'ed73f6b46391b95e1d03c6818a73b8b9', 'phy1025'),
(19, 'atikuraa', 'ma@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'geb102'),
(23, 'rakib', 'rakib@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'chem101'),
(24, 'rakib', 'rakib@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'mat301'),
(26, 'rakib', 'rakib@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'cse103');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
