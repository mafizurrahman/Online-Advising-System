-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2019 at 07:08 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `courseid` varchar(100) NOT NULL,
  `one` char(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `two` char(15) NOT NULL,
  `three` char(20) NOT NULL,
  `four` char(20) NOT NULL,
  `five` char(20) NOT NULL,
  `six` char(20) NOT NULL,
  `seven` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `courseid`, `one`, `email`, `two`, `three`, `four`, `five`, `six`, `seven`) VALUES
(0, 'Mafizur Rahman', 'cse102', 'agree', 'mahfuzmarjan777@gmail.com', 'nutral', 'agree', 'agree', 'agree', 'agree', 'GOOD'),
(0, 'ramim', 'gen239', 'disagree', 'ramim@gmail.om', 'disagree', 'disagree', 'nutral', 'disagree', 'disagree', 'BAD'),
(0, 'noyon', 'cse205', 'agree', 'rakib@gmail.com', 'agree', 'agree', 'nutral', 'disagree', 'nutral', 'BAD'),
(0, 'robin', 'cse498', 'nutral', 'maas@gmail.com', 'disagree', 'nutral', 'nutral', 'disagree', 'nutral', 'BAD'),
(0, 'rakib', 'cse345', 'agree', 'admin@gmail.com', 'nutral', 'nutral', 'disagree', 'disagree', 'disagree', 'GOOD'),
(0, 'rakib', 'cse345', 'agree', 'admin@gmail.com', 'nutral', 'nutral', 'disagree', 'disagree', 'disagree', 'GOOD'),
(0, 'rakib', 'chem109', 'agree', 'rakib1@gmail.com', 'agree', 'agree', 'agree', 'nutral', 'agree', 'GOOD'),
(0, 'Mafizur Rahman', 'gen201', 'agree', 'rmafizur10@gmail.com', 'agree', 'agree', 'agree', 'agree', 'agree', 'GOOD'),
(0, 'dwb', 'cse102', 'agree', 'rmafizkur10@gmail.com', 'nutral', 'nutral', 'nutral', 'nutral', 'disagree', 'BAD'),
(0, 'marjan', 'gen201', 'agree', 'rmafiszur10@gmail.com', 'agree', 'agree', 'agree', 'nutral', 'nutral', 'NEUTRAL'),
(0, 'noyon', 'gen201', 'agree', 'mahfhuzmarjan777@gmail.com', 'nutral', 'agree', 'disagree', 'disagree', 'agree', 'NEUTRAL'),
(0, 'noyon', 'cse564', 'agree', 'rmafizur100@gmail.com', 'agree', 'nutral', 'nutral', 'agree', 'agree', 'GOOD');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
