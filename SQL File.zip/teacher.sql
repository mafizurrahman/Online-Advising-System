-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2019 at 07:08 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(10) NOT NULL,
  `courseid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `username`, `email`, `password`, `courseid`) VALUES
(1, 'DMAN', 'rmafizur10@gmail.com', '0cc175b9c0', 'cse102'),
(2, 'shanto', 'mahfuzmarjan777@gmail.com', '0cc175b9c0', 'cse102'),
(3, 'aaaaaaaam', 'aeaaasaaa@gmail.com', '710307f6eb', 'cse105'),
(4, 'MMSU', 'MM@gmail.com', '94af08f91e', 'cse498'),
(5, 'MMSU', 'MMa@gmail.com', '94af08f91e', 'cse498'),
(6, 'cccccccc', 'mahfuzamarjan777@gmail.com', '0cc175b9c0', 'cse205'),
(7, 'mkn', 'mkn@gmail.com', '21232f297a', 'cse345'),
(8, 'msrn', 'msrn@gmail.com', '21232f297a', 'chem109'),
(9, 'mkn', 'hchtkrrrjj@gmail.com', '0cc175b9c0', 'gen201'),
(10, 'SIS', 'mahfuzmarjan777@gmail.com', 'fb5be496b0', 'gen201'),
(11, 'dln', 'a@gmail.com', '8277e0910d', 'gen201'),
(12, 'admin', 'aa@gmail.com', '0cc175b9c0', 'cse498'),
(13, 'js', 'mahfuzmarjan777@gmail.com', '03c7c0ace3', 'gen201');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
