<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="header">
	<h2><b><font color="white"> Welcome to your profile</font></b></h2>
</div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<h3><p>Hey!!    <strong><font color="blue"><?php echo $_SESSION['username']; ?></font></strong></p></h3>
		
		
    	
    <?php endif ?>
	<!--<p><a href="userdata.php"> click here to continue  AS a student </a></p>-->
	
	


</div>
		
		
	
	
	<p><ul> <h3><a href="index.php?logout='1'" style="color: white;">LOGOUT</a></ul></h3> </p>
	
	
	
<div>

<!DOCTYPE html>
<html lang="en">
<head>

<title>CSS Website Layout</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background-color: powderblue;
}

/* Style the header */
.header {
  background-color: grey;
  padding: 10px;
  text-align: center;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>



<div class="topnav">
  <a href="chat/login.php">	CHATTING FORUM</a>
  <a href="courseevaluation.php">EVALUATION</a>
  <a href="#">Link</a>
</div>

<div class="row">
  <div class="column">
    <h2>Personal Information</h2>
    
	

<?php  //include('try/regiser.php')

//session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname="registration";

// Create connection
$link = new mysqli($servername, $username, $password,$dbname);
$user = $_SESSION['username'];

 
// Attempt select query execution
 $sql = "SELECT * FROM course where username='$user'";

  
		
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table border='3'>";
            echo "<tr>";
               // echo "<th>id</th>";
                echo "<th>username</th>";
                echo "<th>email</th>";
				 echo "<th>courseid</th>";
				
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
              //  echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
				 echo "<td>" . $row['courseid'] . "</td>";
               
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
	
  </div>
  
  <div class="column">
    <h2>QUIZ</h2>
     <h2>Hello User!! There is a simple quick quizz for you</h2>
	<a href="quiz/index.php" class="w3-button w3-black"><b><h3>Click Me To Join</h3></b></a>
    
	</div>
  
  <div class="column">
    <img src="logo.jpg" alt="" width="250" height="155">

    
  </div>
</div>

</body>
</html>

	
</div>	
	
	
	
	
	
	
	
	
	
	
		
    	
		
		
</body>
</html>