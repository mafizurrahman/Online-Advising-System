<?php
session_start(); $username = $password = $userError = $passError = '';
if(isset($_POST['sub'])){
  $username = $_POST['username']; $password = $_POST['password'];
  if($username === 'admin' && $password === 'password'){
    $_SESSION['login'] = true; header('LOCATION:adminfirst.html'); die();
  }
  if($username !== 'admin')$userError = 'Invalid Username';
  if($password !== 'password')$passError = 'Invalid Password';
}
?>
<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>
   <head>
     <meta http-equiv='content-type' content='text/html;charset=utf-8' />
     <title>Login</title>
     <style type='text.css'>
       @import common.css;
     </style>
   </head>
<body style="background-color:powderblue;">
<br><img src="admin.png" alt="admin" width="150" height="150"></br>
<p><h2>  Admin Panel</h2></p>

<center>
<table border="5">
<tr>
<td>

  <form name='input' action='<?php echo $_SERVER['PHP_SELF'];?>' method='post'>
  <p><b>ENTER THE USERNAME</b></P>
    <label for='username'></label><input type='text' value='<?php echo $username;?>' id='username' name='username' />
    <div class='error'><?php echo $userError;?></div>
	<p><b>ENTER THE PASSWORD</b></P>
    <label for='password'></label><input type='password' value='<?php echo $password;?>' id='password' name='password' />
    <div class='error'><?php echo $passError;?></div>
    <br><center><input type='submit' value='submit' name='sub' /></center></br>
  </form>
  
  </tr>
  </td>
  </table></center>
  <script type='text/javascript' src='common.js'></script>
</body>
</html>