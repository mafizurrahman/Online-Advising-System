
<!DOCTYPE html>
<html lang="en">
<head>

<title>CSS Website Layout</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background-color: powderblue;
}

/* Style the header */
.header {
  background-color: #f1f1f1;
  padding: 20px;
  text-align: center;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>

<div class="header">
  <h1><i>WELCOME TO COURSE EVALUATION</i></h1>
 
</div>

<div class="topnav">
 
</div>

<div class="row">
  <div class="column">
    <h3><b><i><font color="maroon">COURSE</b></i></font ></h3>
    
	

<?php  //include('try/regiser.php')

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname="registration";

// Create connection
$link = new mysqli($servername, $username, $password,$dbname);
$user = $_SESSION['username'];

 
// Attempt select query execution
 $sql = "SELECT * FROM course where username='$user'";

  
		
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
               // echo "<th>id</th>";
                //echo "<th><h3><i>courseid</i></h3></th>";
				 
            
				
            echo "</tr>";
			
        while($row = mysqli_fetch_array($result)){
			
            echo "<tr>";
              //  echo "<td>" . $row['id'] . "</td>";
                echo "<td><h3>" . $row['courseid'] . "</h3></td>";
				 //echo "<td>" . $row['courseid'] . "</td>";
         // echo "<a href='#'>link</a>";
            echo "</tr>";
        }
        echo "</table>";
		
		
        
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>

	
  </div>
  
  <div class="column">
   
  
    <?php  //include('try/regiser.php')



$servername = "localhost";
$username = "root";
$password = "";
$dbname="registration";

// Create connection
$link = new mysqli($servername, $username, $password,$dbname);
$user = $_SESSION['username'];

 
// Attempt select query execution
 $sql = "SELECT * FROM course where username='$user'";

  
		
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
               // echo "<th>id</th>";
                
				// echo "<th>courseid</th>";
            echo "<h3><b><i>EVALUATE YOUR COURSE</b></i></h3>";
				echo"<br>";
            echo "</tr>";
			
        while($row = mysqli_fetch_array($result)){
			
            echo "<tr>";
             //  echo "EVALUATE YOUR COURSE";
               // echo "<td><h4>" . $row['courseid'] . "</h4></td>";
				 //echo "<td>" . $row['courseid'] . "</td>";
          echo "<h3><a href='#'>EVALUATE</a></h3>";
		  echo"<br>";
            echo "</tr>";
        }
        echo "</table>";
		
		
        
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
  
  </div>
  
  <div class="column">
   
	</div>
</div>
<footer>
  <p>Powered By: EAST WEST UNIVERSITY</p>
  <p>Contact information: <a href="ewubd.edu">
  ewubd.edu</a>.</p>
</footer>
</body>
</html>

