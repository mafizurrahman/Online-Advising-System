






<!DOCTYPE html>
<html lang="en">
<head>

<title>CSS Website Layout</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background-color: coral;
}

/* Style the header */
.header {
  background-color: #f1f1f1;
  padding: 20px;
  text-align: center;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width:600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>

<div class="header">
  <h1><i>EVALUATION RESULT</i></h1>
 
</div>



<div class="row">
  <div class="column">
    <h2>EVALUATION RESULT</h2>
    
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname="registration";

$link = mysqli_connect("localhost", "root", "", "registration");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT username,seven,courseid FROM register ";
//$sql="SELECT username,COUNT(seven) as new,courseid FROM register where seven="GOOD ""

if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
               
                echo "<th><h3><i>STUDENT</i></h3></th>";
				echo "<th><h3><i>OVERALL COURSE AND FACULTY REVIEW</i></h3></th>";
				echo "<th><h3><i>COURSE</i></h3></th>";
				
				
            echo "</tr>";
			echo"--------------------------------------------------------------";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
               
                
                echo "<td><h4>" . $row['username'] . "</h4></td>";
				echo "<td><h4>" . $row['seven'] . "</h4></td>";
			echo "<td><h4>" . $row['courseid'] . "</h4></td>";
			
            echo "</tr>";
			
        }
        echo "</table>";
		echo"----------------------------------------------------------------";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
  
  
  
  
  </div>
  
  <div class="column">
    <h2>address</h2>
   <?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname="registration";

$link = mysqli_connect("localhost", "root", "", "registration");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$user = $_SESSION['courseid'];
 
// Attempt select query execution
$sql = "SELECT * FROM register where courseid=$user";
//$sql="SELECT username,COUNT(seven) as new,courseid FROM register where seven="GOOD ""

if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
               
                echo "<th><h3><i>one</i></h3></th>";
				
				echo "<th><h3><i>two</i></h3></th>";
				echo "<th><h3><i>three</i></h3></th>";
				echo "<th><h3><i>four</i></h3></th>";
				echo "<th><h3><i>five</i></h3></th>";
				echo "<th><h3><i>six</i></h3></th>";
				echo "<th><h3><i>courseid</i></h3></th>";
				echo "<th><h3><i>username</i></h3></th>";
				
            echo "</tr>";
			echo"--------------------------------------------------------------";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
               
                
                echo "<td><h4>" . $row['one'] . "</h4></td>";
				echo "<td><h4>" . $row['two'] . "</h4></td>";
				echo "<td><h4>" . $row['three'] . "</h4></td>";
				echo "<td><h4>" . $row['four'] . "</h4></td>";
				echo "<td><h4>" . $row['five'] . "</h4></td>";
				echo "<td><h4>" . $row['six'] . "</h4></td>";
			echo "<td><h4>" . $row['courseid'] . "</h4></td>";
			echo "<td><h4>" . $row['username'] . "</h4></td>";
			
            echo "</tr>";
			
        }
        echo "</table>";
		echo"----------------------------------------------------------------";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
  
  
   </div>
  
  <div class="column">
    <h2>Column</h2>
     </div>
</div>

</body>
</html>
