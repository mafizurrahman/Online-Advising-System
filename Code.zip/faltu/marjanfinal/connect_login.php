<?php
   $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "youtube";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
if(isset($_POST["submit"])){
	//require_once("configure.php");
	$name = $_POST['Name'];
	$password=$_POST['Password'];
	$q='SELECT * FROM register where username ="'.$name.'" and password ="'.$password.'"';
	$r=mysqli_query($conn, $q);
	if(mysqli_num_rows($r)>0){
		echo "you are now logged in";
		 
		// header("location:practice.html");
	}
	else{
		//header("location:login.html");
		echo "your password and user name do not match ";
	}
}
/*$sql = "INSERT INTO logint (username,password)
VALUES ('".$_POST["user_name"]."','".$_POST["user_pass"]."')";

if ($conn->query($sql) === TRUE) {
echo "<script type= 'text/javascript'>alert('New record created successfully');</script>";
} else {
echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $conn->error."');</script>";
}
echo "Connected successfully";
$conn->close();*/

?>